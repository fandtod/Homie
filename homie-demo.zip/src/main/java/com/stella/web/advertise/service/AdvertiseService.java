package com.stella.web.advertise.service;

import java.util.List;

import com.stella.web.advertise.vo.Advertise;

public interface AdvertiseService {

	List<Advertise> getAdvertise();

}
